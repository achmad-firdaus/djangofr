from django.db import models
from hitcount.models import HitCount
from hitcount.views import HitCountMixin
# Create your models here.

from django.utils.encoding import python_2_unicode_compatible
from django.contrib.contenttypes.fields import GenericRelation

from hitcount.models import HitCountMixin
from hitcount.settings import MODEL_HITCOUNT
from django import forms
from django.forms import ModelForm


class IpModel(models.Model):
    ip = models.CharField(max_length=100)

    def __str__(self):
        return self.ip


class Post(models.Model):
    title = models.CharField(max_length=200)
    title1 = models.CharField(max_length=200)
    created = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title


class Destinations(models.Model):
    first_name = models.CharField(max_length=100)
    lst_name = models.CharField(max_length=100)
    address = models.CharField(max_length=200)
    # views = models.ManyToManyField(
    #     IpModel, related_name="post_views", blank=True)

    # def total_views(self):
    #     return self.views.count()


# @python_2_unicode_compatible
# class Post(models.Model, HitCountMixin):
#     title = models.CharField(max_length=200)
#     content = models.TextField()
#     hit_count_generic = GenericRelation(
#         MODEL_HITCOUNT, object_id_field='object_pk',
#         related_query_name='hit_count_generic_relation')

#     def __str__(self):
#         return "Post title: %s" % self.title


class Viewscount(models.Model):
    # viewsc = models.IntegerField()
    # viewsc = models.CharField(max_length=100)
    name = models.CharField(max_length=100)
    views = models.ManyToManyField(
        IpModel, related_name="Viewscount", blank=True)

    def total_views(self):
        return self.views.count()
# python .\manage.py makemigrations
# python .\manage.py sqlmigrate calc 0002
# python manage.py migrate
