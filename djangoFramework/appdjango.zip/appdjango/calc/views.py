from django.shortcuts import render
from django.http import HttpResponse
from hitcount.models import HitCount
from hitcount.views import HitCountMixin
# Create your views here.

# call model
from .models import *
from .models import Destinations, Viewscount, IpModel, Post

# from hitcount.views import HitCountDetailView


# from django.views.decorators.csrf import ensure_csrf_cookie
# from django.views.generic import DetailView, TemplateView

# from hitcount.views import HitCountDetailView

from django import forms
from django.forms import ModelForm


def home(request):
    dests = Destinations.objects.all()
    view = Viewscount.objects.all()

    # hit_count()
    count_hit = True
    # hit_count_response = HitCountMixin.hit_count(request, hit_count)
    return render(request, 'views/dashboard.html', {'dests': dests, 'views': view})


def add(request):
    dests = Destinations.objects.all()
    view = Viewscount.objects.all()
    val1 = int(request.POST['data'])
    vals = val1
    form = PostForm()

    if request.method == 'POST':
        form = PostForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('')
            print(form)
    # hit_count()
    count_hit = True
    # hit_count_response = HitCountMixin.hit_count(request, hit_count)
    return render(request, 'views/dashboard.html', {'dests': dests, 'views': view, 'val1': vals})


# class PostMixinDetailView(object):
#     """
#     Mixin to same us some typing.  Adds context for us!
#     """
#     model = Post

#     def get_context_data(self, **kwargs):
#         context = super(PostMixinDetailView, self).get_context_data(**kwargs)
#         context['post_list'] = Post.objects.all()[:5]
#         context['post_views'] = ["ajax", "detail", "detail-with-count"]
#         return context


# class PostDetailView(PostMixinDetailView, HitCountDetailView):
#     """
#     Generic hitcount class based view.
#     """
#     pass


# class PostCountHitDetailView(HitCountDetailView):

#     dests = Destinations      # your model goes here
#     count_hit = True    # set to True if you want it to try and count the hit
#     template_name = "views/dashboard.html"
#     # slug_field = "slug"
#     # count_hit = True


def get(self, request, *args, **kwargs):
    self.object = self.get_object()
    context = self.get_context_data(object=self.object)
    ip = get_client_ip(self.request)
    print(ip)
    IpModel.objects.create(ip=ip)
    post.view.add(IpModel.objects.get(ip=ip))


def get_client_ip(request):
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip
