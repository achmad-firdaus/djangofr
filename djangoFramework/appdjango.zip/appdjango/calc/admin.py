from django.contrib import admin
from .models import *
# from .models import IpModel
# Register your models here.

admin.site.register(IpModel)
admin.site.register(Destinations)
admin.site.register(Viewscount)
admin.site.register(Post)
