Additional Authors and Thanks
=============================

I've had some help and I'm very grateful!  You can always look at the `contributors`_ on GitHub to get a clearer picture.

This doesn't include everyone and if I missed someone let me know I will add it.

Thanks goes to:

 * Basil Shubin and his work at `django-hitcount-headless <https:/github.com/bashu/django-hitcount-headless>`_ as well as his Russian translations
 * ariddell for putting the `setup.py` package together for me

.. _contributors: https://github.com/thornomad/django-hitcount/graphs/contributors
