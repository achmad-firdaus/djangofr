from __future__ import unicode_literals

VERSION = (1, 3, 3)

__version__ = '.'.join(str(i) for i in VERSION)
